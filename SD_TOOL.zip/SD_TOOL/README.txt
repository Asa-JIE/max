SD_TOOL V8

Folder Structure:
SD_TOOL/
    startup.ms
    addmenu.ms
    delete_menu.ms
    install_sd_tool.bat
    uninstall_sd_tool.bat
    README.txt
    script/
        *.ms
    menu/
        menu_items.ini
    Library/
        *.dll

Recommended Installation:
- Double click `install_sd_tool.bat`
- This only writes a tiny loader into your Max user startup folder
- It does NOT copy the whole SD_TOOL folder
- The loader directly points to your P4 synced SD_TOOL path
- Restart 3ds Max

How it works:
- `install_sd_tool.bat` writes `SDTool_loader.ms` to:
  `%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\scripts\Startup\`
- That loader contains one line:
  `fileIn @"<P4_PATH>\SD_TOOL\startup.ms"`
- When Max starts, it runs the loader, which in turn runs startup.ms
- startup.ms automatically derives the SD_TOOL root from its own location
- Everything else (`script/`, `menu/`, `Library/`) is accessed relative to that root
- No files are copied to `%LOCALAPPDATA%` except the loader

What happens when you sync new files via P4:
- Just restart Max. The updated scripts run automatically from the P4 path.
- For adding new buttons, update `menu/menu_items.ini`, then click `SDTool > Update Menu`.

Update Existing Tools / Add New Tools:
1. Put tool scripts into `script/`
2. Put DLL dependencies into `Library/`
3. Add menu entries into `menu/menu_items.ini`
4. Click `SDTool > Update Menu`

menu_items.ini example:
[SDTool_V8_05_CheckTool]
label=Check Tool
tooltip=Check Tool
mode=exact
target=checktool.ms

Modes:
- `mode=exact` loads the exact `.ms` file from `script/`
- `mode=prefix` finds the first `.ms` file in `script/` matching the prefix

Uninstall:
- Run `uninstall_sd_tool.bat`
- Restart 3ds Max

Notes:
- `Update Menu` refreshes the menu structure only
- Tool execution always uses the latest script file from the P4 source
- `checktool.ms` loads DLLs from the same source `Library/` directory