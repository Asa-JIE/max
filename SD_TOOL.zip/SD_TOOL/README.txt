



[SDTool] menu created.
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\AsaSkinBipedBuilder_v8_ValidateFix.ms
Asa Skin Biped Builder v8 ready.
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\Asabonechain_bake.ms
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\AsaSkinBipedBuilder_v8_ValidateFix.ms
Asa Skin Biped Builder v8 ready.
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\Asabiach_bip_worldcopy_skeleton_framerange_fixed.ms
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\Asabonechain_bake.ms
[SDTool] menu created.
[SDTool] run: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\AsaSkinBipedBuilder_v8_ValidateFix.ms
Asa Skin Biped Builder v8 ready.
-- MAXScript RunScriptCommand Script Exception:
-- Compile error: Already defined:  version
--  In line: _ca0 = attributes 'Custom Attributes' (parameters main rollout:params ('Version' t
-- MAXScript RunScriptCommand Script Exception:
-- Compile error: Already defined:  version
--  In line: _ca0 = attributes 'Custom Attributes' (parameters main rollout:params ('Version' t
-- MAXScript RunScriptCommand Script Exception:
-- Compile error: Already defined:  version
--  In line: _ca0 = attributes 'Custom Attributes' (parameters main rollout:params ('Version' t
-- MAXScript RunScriptCommand Script Exception:
-- Compile error: Already defined:  version
--  In line: _ca0 = attributes 'Custom Attributes' (parameters main rollout:params ('Version' t
-- Error occurred in anonymous codeblock; filename: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms; position: 2243; line: 91
>> MAXScript MacroScript Compile - C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms, offset 2243; Exception:
-- Syntax error: at local, expected macroScript
--  In line: local c <<
-- Error occurred in anonymous codeblock; filename: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms; position: 2563; line: 102
>> MAXScript MacroScript Compile - C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms, offset 2563; Exception:
-- Syntax error: at name, expected macroScript
--  In line: urrentMode = <<
-- Error occurred in anonymous codeblock; filename: C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms; position: 2870; line: 109
>> MAXScript MacroScript Compile - C:\Program Files\Autodesk\3ds Max 2020\scripts\SD_TOOL\startup.ms, offset 2870; Exception:
-- Syntax error: at name, expected macroScript
--  In line: n c <<

