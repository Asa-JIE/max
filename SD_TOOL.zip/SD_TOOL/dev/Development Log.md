
### ADD FEATURE
1 
Add Path
Make sure the files for the features you want to add already exist in the specified file path.

2 
Add menu bar features to menu_items.ini
```html
Template
<a 
[SDTool_V8_04_ExportFBX]
label=Export FBX
tooltip=Export FBX
mode=exact
target=exportfbx.ms
```

---
File Hierarchy
```html
Template
<a 
      SD_TOOL/
      script/     
            AsaSkinBipedBuilder_v8_ValidateFix.ms
            Asabiach_bip_worldcopy_skeleton_framerange_fixed.ms
            Asabonechain_bake.ms
            exportfbx.ms          
      menu/
            menu_items.ini
      startup.ms
      addmenu.ms
      delete_menu.ms
      README
```
---

Regression Testing

* The cache for the old version has been cleared.
* The new SD_TOOL folder has been copied to the corresponding maya/scripts directory.
* After dragging the Add Menu file into 3ds Max, the corresponding menu was successfully added to the menu bar.
  * All buttons are displayed correctly.
  * Whether Max is restarted or reopened, the menu is retained and is not lost.


* All function buttons in the menu have been tested and are working properly.
* After adding the corresponding .ms files for the new features to the scripts directory and adding the corresponding button configurations to menu_items:

  * Clicking “Update Menu” correctly refreshes the menu.
  * New function buttons are successfully added to the menu.
  * The new features work as expected.