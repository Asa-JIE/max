@echo off
setlocal

set "SD_TOOL_PATH=%~dp0"
if "%SD_TOOL_PATH:~-1%"=="\" set "SD_TOOL_PATH=%SD_TOOL_PATH:~0,-1%"

set "MAX_USER_STARTUP=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\scripts\Startup"
set "MAX_USER_startup=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\scripts\startup"
set "LOADER_FILE=%MAX_USER_STARTUP%\SDTool_loader.ms"
set "LOADER_FILE_LOWER=%MAX_USER_startup%\SDTool_loader.ms"
set "USER_MACROS=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\usermacros"
set "BOOTSTRAP_MACRO=%USER_MACROS%\SDTool_bootstrap.mcr"

if not exist "%MAX_USER_STARTUP%" mkdir "%MAX_USER_STARTUP%"
if not exist "%MAX_USER_startup%" mkdir "%MAX_USER_startup%"
if not exist "%USER_MACROS%" mkdir "%USER_MACROS%"

>"%LOADER_FILE%" echo try(fileIn @"%SD_TOOL_PATH%\startup.ms")catch(format "[SDTool][ERROR] loader failed: %%\n" ^(getCurrentException()^))
>"%LOADER_FILE_LOWER%" echo try(fileIn @"%SD_TOOL_PATH%\startup.ms")catch(format "[SDTool][ERROR] loader failed: %%\n" ^(getCurrentException()^))
>"%BOOTSTRAP_MACRO%" echo try(fileIn @"%SD_TOOL_PATH%\startup.ms")catch()

echo.
echo SDTool linked from:
echo %SD_TOOL_PATH%
echo.
echo Startup loader written to:
echo %LOADER_FILE%
echo %LOADER_FILE_LOWER%
echo Bootstrap macro written to:
echo %BOOTSTRAP_MACRO%
echo.
echo Restart 3ds Max to auto-load the menu.
echo.
echo No files were copied. Everything runs directly from the P4 path above.
echo When you sync the latest version via P4, just restart Max.
echo.
pause