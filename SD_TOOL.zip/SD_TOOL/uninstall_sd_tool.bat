@echo off
setlocal

set "MAX_USER_STARTUP=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\scripts\Startup"
set "MAX_USER_startup=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\scripts\startup"
set "LOADER_FILE=%MAX_USER_STARTUP%\SDTool_loader.ms"
set "LOADER_FILE_LOWER=%MAX_USER_startup%\SDTool_loader.ms"
set "DYNAMIC_MCR=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\usermacros\SDTool_dynamic_menu.mcr"
set "BOOTSTRAP_MACRO=%LOCALAPPDATA%\Autodesk\3dsMax\2020 - 64bit\ENU\usermacros\SDTool_bootstrap.mcr"

if exist "%LOADER_FILE%" del /Q "%LOADER_FILE%"
if exist "%LOADER_FILE_LOWER%" del /Q "%LOADER_FILE_LOWER%"
if exist "%DYNAMIC_MCR%" del /Q "%DYNAMIC_MCR%"
if exist "%BOOTSTRAP_MACRO%" del /Q "%BOOTSTRAP_MACRO%"

echo.
echo SDTool loader and macros removed from user scripts.
echo.
echo Note: the SD_TOOL folder itself was not removed because it now
echo runs directly from the P4 source path and was never copied.
echo.
echo Restart 3ds Max to clear any loaded menu state.
echo.
pause